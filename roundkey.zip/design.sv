module iniroundkey(st_i,round_z,st_o);
  input [127:0] st_i;
  input [127:0] round_z;
  output [127:0] st_o;
  assign st_o= st_i^round_z;
endmodule