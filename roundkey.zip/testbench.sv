module tb_iniroundkey();
  reg [127:0] st_i;
  reg [127:0] round_z;
  wire [127:0] st_o;
  iniroundkey uut1(st_i,round_z,st_o );
  initial begin
  st_i=128'h 00112233445566778899AABBCCDDEEFF;
  round_z=128'h 000102030405060708090A0B0C0D0E0F;
    $display("text by user= %h",st_i);
    $display("secret key by user= %h",round_z);
    #10;
    $display("output key= %h",st_o);
  end
  initial
    begin
      $dumpfile("first");
      $dumpvars(1);
    end
endmodule
      
      