module tb_keyexpansion_128();

reg  [127:0] key;

wire [127:0] rk0;
wire [127:0] rk1;
wire [127:0] rk2;
wire [127:0] rk3;
wire [127:0] rk4;
wire [127:0] rk5;
wire [127:0] rk6;
wire [127:0] rk7;
wire [127:0] rk8;
wire [127:0] rk9;
wire [127:0] rk10;

keyexpansion_128 uut1(
    .key(key),
    .rk0(rk0),
    .rk1(rk1),
    .rk2(rk2),
    .rk3(rk3),
    .rk4(rk4),
    .rk5(rk5),
    .rk6(rk6),
    .rk7(rk7),
    .rk8(rk8),
    .rk9(rk9),
    .rk10(rk10)
);

initial begin

    $dumpfile("keyexpansion.vcd");
  $dumpvars(0, tb_keyexpansion_128);

    // AES-128 standard key
    key = 128'h2b7e151628aed2a6abf7158809cf4f3c;

    #10;

    $display("Original Key = %h", rk0);
    $display("Round Key 1  = %h", rk1);
    $display("Round Key 2  = %h", rk2);
    $display("Round Key 3  = %h", rk3);
    $display("Round Key 4  = %h", rk4);
    $display("Round Key 5  = %h", rk5);
    $display("Round Key 6  = %h", rk6);
    $display("Round Key 7  = %h", rk7);
    $display("Round Key 8  = %h", rk8);
    $display("Round Key 9  = %h", rk9);
    $display("Round Key 10 = %h", rk10);

    $finish;

end
endmodule