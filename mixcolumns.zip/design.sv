//multiply x02 of galios submodule
module xtime(in,out)  ;
  input [7:0]in;
  output [7:0] out;
  assign out= in[7]?((in<<1)^8'h1B):(in<<1);
endmodule

//multiply x03 of galios submodule
module mul3(in1,out1);
  input [7:0]in1;
  output[7:0]out1;
  wire[7:0]xtime_out;
  xtime x1(.in(in1),.out(xtime_out));
  assign out1=xtime_out^in1;
           endmodule
//mixcoloumns main module
           module mixcoloumns(a0,a1,a2,a3,b0,b1,b2,b3);
             input [7:0]a0,a1,a2,a3;
             output [7:0]b0,b1,b2,b3;
             wire [7:0] a0_x2,a1_x2,a2_x2,a3_x2;
             wire [7:0] a0_x3,a1_x3,a2_x3,a3_x3;
//multiply by x02
             xtime x0(a0,a0_x2);
             xtime x1(a1,a1_x2);
             xtime x2(a2,a2_x2);
             xtime x3(a3,a3_x2);
 //multiply by x03
  assign a0_x3=a0_x2^a0;
  assign a1_x3=a1_x2^a1;
  assign a2_x3=a2_x2^a2;
  assign a3_x3=a3_x2^a3;
 //galiosfield equations
  assign b0=a0_x2^a1_x3^a2^a3;
  assign b1=a0^a1_x2^a2_x3^a3;
  assign b2=a0^a1^a2_x2^a3_x3;
  assign b3=a0_x3^a1^a2^a3_x2;
           endmodule
//since we have 128 bit, we instantiate main module into 4coloumns
module mixcoloumns_128(
    input  [127:0] state,
    output [127:0] out
);

wire [7:0] b0,b1,b2,b3;
wire [7:0] b4,b5,b6,b7;
wire [7:0] b8,b9,b10,b11;
wire [7:0] b12,b13,b14,b15;


// Column 0
mixcoloumns c0(
    .a0(state[127:120]),
    .a1(state[119:112]),
    .a2(state[111:104]),
    .a3(state[103:96]),
  .b0(b0),
    .b1(b1),
    .b2(b2),
    .b3(b3)
);


// Column 1
mixcoloumns c1(
    .a0(state[95:88]),
    .a1(state[87:80]),
    .a2(state[79:72]),
    .a3(state[71:64]),
    .b0(b4),
    .b1(b5),
    .b2(b6),
    .b3(b7)
);


// Column 2
mixcoloumns c2(
    .a0(state[63:56]),
    .a1(state[55:48]),
    .a2(state[47:40]),
    .a3(state[39:32]),
    .b0(b8),
    .b1(b9),
    .b2(b10),
    .b3(b11)
);//instantiating first row of input(state) and output of mix coloumns 


// Column 3
mixcoloumns c3(
    .a0(state[31:24]),
    .a1(state[23:16]),
    .a2(state[15:8]),
    .a3(state[7:0]),
    .b0(b12),
    .b1(b13),
    .b2(b14),
    .b3(b15)
);


// Combine all columns back into 128 bits
assign out = {
    b0,b1,b2,b3,
    b4,b5,b6,b7,
    b8,b9,b10,b11,
    b12,b13,b14,b15
};

endmodule