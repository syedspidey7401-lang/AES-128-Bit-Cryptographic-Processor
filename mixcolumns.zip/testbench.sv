module mixcoloumns_128_tb;

reg  [127:0] state;
wire [127:0] out;


mixcoloumns_128 dut(
    .state(state),
    .out(out)
);


initial begin
$dumpfile("mix.vcd");
    $dumpvars(1);
    
    // AES test vector
    state = 128'hDB135345119020E0AEF22B3DE8C73392;


    #10;


    $display("Input  = %h", state);
    $display("Output = %h", out);

$display("C0 = %h %h %h %h",
out[127:120],out[119:112],out[111:104],out[103:96]);

$display("C1 = %h %h %h %h",
out[95:88],out[87:80],out[79:72],out[71:64]);

$display("C2 = %h %h %h %h",
out[63:56],out[55:48],out[47:40],out[39:32]);

$display("C3 = %h %h %h %h",
out[31:24],out[23:16],out[15:8],out[7:0]);
  if(out == 128'h8E4DA1BC49AAFA585C114D4A38BAE4E8)
        $display("MixColumns PASS");
    else
        $display("MixColumns FAIL");
$finish;
  end
endmodule