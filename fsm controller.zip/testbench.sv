
module tb_fsmcontr();

reg clk;
reg rst;
reg start;
wire done;
wire [3:0] round;
  fsmcontr uut1(clk,rst,start,round,done);
// Clock generation
initial begin
    clk = 0;
    forever #5 clk = ~clk;
end

// Test sequence
initial begin

    $dumpfile("fsm.vcd");
  $dumpvars(0, tb_fsmcontr);

    rst = 1;
    start = 0;

    #10;
    rst = 0;

    #10;
    start = 1;

    #10;
    start = 0;

    #150;

    $finish;
end

// Monitor outputs
initial begin
    $monitor("Time=%0t  Round=%0d  Done=%b  State=%0d",
              $time, round, done, uut1.current_st);
end

endmodule