module fsmcontr(clk,rst,start,round,done);
  input clk;
  input rst;
  input start;
  output reg done;
  output reg [3:0] round;
  parameter IDLE 		=3'b000,
            init_rnd	= 3'b001,
  			rnd			=3'b010,
  			final_rnd	=3'b011,
  			DONE		=3'b100;
  
  reg [2:0] current_st,next_st;
  //memory for fsm
  always@(posedge clk or posedge rst)
    if(rst)
      current_st<=IDLE;
  else
    current_st<=next_st;    
  //main for fsm
  always@(*)
     begin
       case(current_st)
     IDLE:
       begin
       if(start)
         next_st=init_rnd;
         else
           next_st=IDLE;
       end
     init_rnd:
       begin
         next_st=rnd;
       end
     rnd:
       begin
         if(round==4'd10)
           next_st=final_rnd;
         else
           next_st=rnd; //keeps checking till it reaches 10
       end
         final_rnd:
           begin
             next_st=DONE;
           end
         DONE:
           begin
             next_st=IDLE;
           end
         default:
           next_st=IDLE;
       endcase
     end
 //round counter
  always@(*)
    begin
      done=0;
      case(current_st)
        IDLE:
          done=0;
        init_rnd:
          done=0;
        rnd:
          done=0;
        final_rnd:
          done=0;
        DONE:
          done=1;
      endcase
    end
  always @(posedge clk or posedge rst)
begin
  if(rst)
        round <= 4'd0;
    else
    begin
        case(current_st)

            IDLE:
                round <= 4'd0;

            init_rnd:
                round <= 4'd1;

            rnd:
            begin
                if(round < 4'd10)
                    round <= round + 1;
            end

            final_rnd:
                round <= round;

            DONE:
                round <= 4'd0;

        endcase
    end
end
endmodule     