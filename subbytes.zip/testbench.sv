module tb_sb();
  reg [127:0]s_in;
  wire[127:0]s_out;
  sb uut1(s_in,s_out);
  initial
    begin
      s_in=128'h00112233445566778899AABBCCDDEEFF;
      #10;
      $display("output= %h",s_out);
    end
  initial begin
    $dumpfile("subbytes.vcd");
    $dumpvars(1);
    #60;
    $finish;
    end
  endmodule