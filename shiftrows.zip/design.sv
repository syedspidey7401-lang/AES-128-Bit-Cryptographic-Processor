module shiftr(
  input  [127:0] state_in,
    output [127:0] s_out
);

assign s_out = {

    //  (No shift)
    state_in[127:120],
    state_in[119:112],
    state_in[111:104],
    state_in[103:96],

    //  (Shift left by 1)
    state_in[87:80],
    state_in[79:72],
    state_in[71:64],
    state_in[95:88],

    //  (Shift left by 2)
    state_in[47:40],
    state_in[39:32],
    state_in[63:56],
    state_in[55:48],

    //  (Shift left by 3)
    state_in[7:0],
    state_in[31:24],
    state_in[23:16],
    state_in[15:8]

};

endmodule