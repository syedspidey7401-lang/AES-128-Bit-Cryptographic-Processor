module shiftr_tb;

  reg  [127:0] state_in;
wire [127:0] s_out;

  shiftr uut1(state_in,s_out);

initial begin

    state_in = 128'h00112233445566778899AABBCCDDEEFF;

    #10;

  $display("Input  = %h", state_in);
    $display("Output = %h", s_out);
end
     initial begin 
       $dumpfile("shiftrows.vcd");
      $dumpvars(1);
      #60;
    

$finish;
     end
endmodule
  
  
  
  
  
  
  
  
  